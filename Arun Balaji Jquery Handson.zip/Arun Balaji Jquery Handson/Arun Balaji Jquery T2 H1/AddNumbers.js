function add_two_number()
{
   $("#display_message").show();
   if($("#num1").val()=="" || $("#num2").val()=="")
   {
      $("#message").html("<font color='red'>Pls. Enter The Values.</font>");
   }
   else
  {
    var answer=parseInt($("#num1").val()) + parseInt($("#num2").val())
       
    $("#display_message").html("<font color='green'><b>"+answer+"</b></font>");
 $("#answer").val(answer);
 
   }
}