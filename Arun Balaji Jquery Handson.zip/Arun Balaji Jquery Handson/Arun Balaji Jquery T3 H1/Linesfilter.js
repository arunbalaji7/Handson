$(document).ready(function(){
    $("#search").click(function(){
        var key=$("#word1").val();
        var array=key.split(",");
        var answer="";
        var main=$("#word2").val();
        var text2=main.split(/\n/);
        for(var i=0;i<text2.length;i++){
            for(var j=0;j<array.length;j++){
                if(text2[i].includes(array[j])){
                    var first="";
                    var second="";
                    var sp=text2[i].split(array[j]);
                    first=sp[0];
                    second=sp[1];
                    answer+=first+"<b>"+array[j]+"</b>"+second+", ";
                }

            }
        }
        $("#word3").val(answer)
    })
    
});