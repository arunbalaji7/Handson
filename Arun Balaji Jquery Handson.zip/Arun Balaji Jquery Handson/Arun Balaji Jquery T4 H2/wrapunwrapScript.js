$(document).ready(() => {
    var temp = $("p");
    $("#button").click(function () {
      if (temp.parent().is("div")) {
        temp.unwrap();
      } else {
        temp.wrap("<div>");
      }
    });
  });