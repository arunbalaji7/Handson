$(document).ready(() => {
  $("#box1").click(function () {
    $(this).css("background-color", "yellow");
  });
  $("#box2").click(function () {
    $(this).css("background-color", "green");
  });
  $("#box3").click(function () {
    $(this).css("background-color", "red");
  });
  $("#box4").click(function () {
    $(this).css("background-color", "pink");
  });

  var temp;
  $("#button").click(function () {
    if (temp) {
      temp.appendTo("body");
      $("div").css("display","block");
      $("div").css("margin","0px 0px 2px 0px");
      temp = null;
    } else {
      temp = $("div").detach();
    }
  });
});