$(document).ready(() => {
  $("#button").click(() => {
    var text=$("#message").val();
    console.log(text);
    $("#answer").append(text);
  });

  $("#answer").click(function () {
    console.log("Clicked on message");
    let emoji=document.createElement("img");
    emoji.src="https://cdn.shopify.com/s/files/1/1061/1924/products/Smiling_Emoji_Icon_-_Blushed_large.png?v=1571606114";
    emoji.width=200;
    emoji.height=200;
    $(this).replaceWith(emoji);
  });
});