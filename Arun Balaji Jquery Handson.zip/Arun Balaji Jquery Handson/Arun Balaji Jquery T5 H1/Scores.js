$(document).ready(function() {
    $("input").keyup(() => {
      sum();
    });
  });
  
  function sum() {
    let ans=0;
    $("input").each(function () {
      if(!isNaN(this.value)&&(this.value)!==""){
        ans+=parseFloat(this.value);
      }
    });
    $("#Answer").text(Number(ans).toFixed(2));
  }